EigenTunnel — Patrick EasyStart v3 (macOS)

Open START-HERE.txt and follow the five steps.

Hard cut (wipe and reinstall): trash ~/EigenTunnel before activate.
There is no settings migration.

This pack is pre-set for leaf-patrickmccormick (overlay 10.66.0.2/24).
Gateway connection info is already included (3.130.82.45:51820).
Your private key is created on this Mac and never uploaded.

Home data for this pack: ~/EigenTunnel
Binaries: eigentunneld and eigentunnel-perf-identity.
