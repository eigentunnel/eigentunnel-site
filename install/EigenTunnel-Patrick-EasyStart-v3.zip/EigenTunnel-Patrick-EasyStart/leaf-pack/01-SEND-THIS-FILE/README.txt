After ./install.sh, this folder contains a file named peer.env.

Send peer.env only.
Do not send this README.
Do not send identity.key.
