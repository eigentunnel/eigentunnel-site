The gateway operator may place a file named peer.env in this folder.

You do not create that file.
Do not put identity.key here.
./install.sh connects outbound when the gateway file is here.
