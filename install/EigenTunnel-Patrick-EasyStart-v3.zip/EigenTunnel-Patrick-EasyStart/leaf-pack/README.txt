EigenTunnel leaf (Mac)

Do this once:

    cd eigen-leaf-macos
    ./install.sh

Leave that window open.

When the command says the file is ready, send ONLY this file:

    01-SEND-THIS-FILE/peer.env

The file is named peer.env. Send that one file.

Do not send any other file.
Do not send identity.key.
Do not send the identity folder.

You are done. The gateway operator does the rest.
