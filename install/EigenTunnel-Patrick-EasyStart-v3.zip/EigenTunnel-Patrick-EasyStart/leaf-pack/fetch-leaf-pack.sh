#!/usr/bin/env bash
# EigenTunnel leaf pack fetch stub.
#
# Contract (cloud):
#   POST /v1/eigentunnel/leaf-pack
#   JSON: tenantId, nodeId, inviteToken
#   The invite token is the download capability from accept (1 hour).
#   Response downloadUrl is a short-lived presigned GET.
#   ttlSeconds is at most 3600 and never longer than that download window.
#   inviteTtlSeconds is 172800. enrollTtlSeconds is 604800.
#   The body is a lease entitlement for the pack. It is not an identity key.
#
# This stub accepts the URL and writes a receipt. It does not perform a
# network GET, does not call a cloud API, and does not write identity.key.
set -euo pipefail

url="${EIGENTUNNEL_LEAF_PACK_URL:-}"
if [ -z "$url" ]; then
  echo "EIGENTUNNEL_LEAF_PACK_URL is required" >&2
  exit 1
fi

case "$url" in
  *identity.key*|*"PRIVATE KEY"*|*"privateKey"*|*BEGIN*CERTIFICATE*)
    echo "private key material is not accepted" >&2
    exit 1
    ;;
esac

case "$url" in
  https://*) ;;
  *)
    echo "leaf pack url must be https" >&2
    exit 1
    ;;
esac

receipt="${EIGENTUNNEL_LEAF_PACK_RECEIPT:-}"
if [ -n "$receipt" ]; then
  printf '%s\n' "artifact=eigen-leaf-pack" "url_accepted=1" "identity_key_written=0" > "$receipt"
fi

echo "leaf pack url accepted; network fetch is not performed by this stub" >&2
