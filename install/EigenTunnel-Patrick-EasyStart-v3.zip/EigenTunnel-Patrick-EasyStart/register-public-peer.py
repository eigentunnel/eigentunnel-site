#!/usr/bin/env python3
"""After leaf install, POST public peer fields to rendezvous.

The activate token comes from the invite. The device private key does not
leave the device on this channel. This script refuses peer.env, identity.key,
and PEM private-key text.

No token values belong in git. Pass them in the environment at install time.
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path


REGISTER_PATH = "/v1/eigentunnel/peers/register"
PUBLIC_KEY_RE = re.compile(r"^(?:ed25519:)?[A-Za-z0-9+/]{42,44}={0,2}$")
ENV_ASSIGN = re.compile(r"(?m)^[A-Za-z_][A-Za-z0-9_]{1,64}=.+$")
REFUSED_NAMES = {
    "peer.env",
    "identity.key",
    "private.key",
    "id_rsa",
    "id_ed25519",
}


def main(argv: list[str] | None = None) -> int:
    del argv
    try:
        body = build_body_from_env()
    except SystemExit as err:
        code = err.code
        return int(code) if isinstance(code, int) else 1
    if os.environ.get("EIGENTUNNEL_REGISTER_DRY_RUN", "").strip() in {"1", "true", "yes"}:
        sys.stdout.write(json.dumps(body) + "\n")
        return 0
    url = os.environ.get("EIGENTUNNEL_RENDEZVOUS_URL", "").strip().rstrip("/")
    if not url:
        _fail("rendezvous url is required")
    _post(url + REGISTER_PATH, body)
    sys.stdout.write('{"accepted":true}\n')
    return 0


def build_body_from_env() -> dict:
    """Public fields only. Raises SystemExit on a refused source."""
    token = os.environ.get("EIGENTUNNEL_ACTIVATE_TOKEN", "").strip()
    enroll = os.environ.get("EIGENTUNNEL_ENROLL_TOKEN", "").strip()
    if token and enroll:
        _fail("request field is invalid")
    pubkey = _public_key()
    _refuse_material(pubkey)
    _refuse_material(token)
    _refuse_material(enroll)
    body = {
        "tenantId": _required("EIGENTUNNEL_TENANT_ID"),
        "nodeId": _required("EIGENTUNNEL_NODE_ID"),
        "peerId": _required("EIGENTUNNEL_PEER_ID"),
        "devicePublicKey": pubkey,
    }
    if token:
        body["activateToken"] = token
    elif enroll:
        body["enrollToken"] = enroll
    else:
        _fail("activate token is required", code=401)
    host = os.environ.get("EIGENTUNNEL_ENDPOINT_HOST", "").strip()
    port = os.environ.get("EIGENTUNNEL_ENDPOINT_PORT", "").strip()
    if host or port:
        if not host or not port:
            _fail("request field is invalid")
        try:
            port_number = int(port)
        except ValueError:
            _fail("request field is invalid")
        body["endpoints"] = [
            {"transport": "udp", "host": host, "port": port_number, "source": "reported"}
        ]
    for value in body.values():
        if isinstance(value, str):
            _refuse_material(value)
    return body


def _public_key() -> str:
    inline = os.environ.get("EIGENTUNNEL_DEVICE_PUBLIC_KEY", "").strip()
    path_text = os.environ.get("EIGENTUNNEL_PUBLIC_KEY_FILE", "").strip()
    if inline and path_text:
        _fail("request field is invalid")
    if inline:
        return inline
    if not path_text:
        _fail("device public key is required")
    path = Path(path_text)
    name = path.name.lower()
    if name in REFUSED_NAMES or name.endswith(".pem") or name == "peer.env":
        _fail("peer env is not accepted" if "peer" in name or name.endswith(".env") else "private key material is not accepted")
    if "private" in name and not name.endswith(".pub"):
        _fail("private key material is not accepted")
    try:
        text = path.read_text(encoding="utf-8").strip()
    except OSError:
        _fail("device public key is required")
    _refuse_material(text)
    return text


def _refuse_material(value: str) -> None:
    if not value:
        return
    lowered = value.lower()
    if "private key" in lowered or "identity.key" in lowered:
        _fail("private key material is not accepted")
    if PUBLIC_KEY_RE.fullmatch(value):
        return
    if ENV_ASSIGN.fullmatch(value.strip()) or ("\n" in value and ENV_ASSIGN.search(value)):
        _fail("peer env is not accepted")


def _required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        _fail(name + " is required")
    _refuse_material(value)
    return value


def _post(url: str, body: dict) -> None:
    raw = json.dumps(body).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=raw,
        headers={"content-type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            response.read()
    except urllib.error.HTTPError as err:
        # Do not print the request body. It holds the activate token.
        _fail("register failed", code=err.code if isinstance(err.code, int) else 1)
    except urllib.error.URLError:
        _fail("register failed")


def _fail(message: str, code: int = 1) -> None:
    sys.stderr.write(message + "\n")
    raise SystemExit(code)


if __name__ == "__main__":
    raise SystemExit(main())
