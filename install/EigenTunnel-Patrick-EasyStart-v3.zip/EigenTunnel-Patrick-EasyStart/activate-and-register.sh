#!/usr/bin/env bash
# Usage: ./activate-and-register.sh <activate-token>
# Patrick EasyStart: leaf-patrickmccormick @ 10.66.0.2/24 with gateway peer pre-loaded.
# Arch binaries live in bin/ and are pack payloads (not committed in this repo).
# Hard cut: eigentunneld and eigentunnel-perf-identity only. Wipe and reinstall.
set -euo pipefail
TOKEN="${1:-}"
NODE_ID="${2:-leaf-patrickmccormick}"
OVERLAY="${EIGENTUNNEL_OVERLAY:-10.66.0.2/24}"
if [ -z "$TOKEN" ]; then
  echo "usage: $0 <activate-token>" >&2
  exit 1
fi
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64) SUFFIX=arm64 ;;
  x86_64) SUFFIX=x64 ;;
  *) echo "unsupported arch: $ARCH" >&2; exit 1 ;;
esac
BIN="$ROOT/bin"
export PATH="$BIN:$PATH"

link_primary() {
  local primary="$1"
  if [ ! -e "$BIN/${primary}-$SUFFIX" ]; then
    echo "missing $BIN/${primary}-$SUFFIX" >&2
    exit 1
  fi
  ln -sfn "${primary}-$SUFFIX" "$BIN/$primary"
}

link_primary eigentunnel-perf-identity
link_primary eigentunneld

export EIGENTUNNEL_IDENTITY_BIN="$BIN/eigentunnel-perf-identity"
export EIGENTUNNEL_DAEMON_BIN="$BIN/eigentunneld"

PACK="$ROOT/leaf-pack"
API="${EIGENTUNNEL_RENDEZVOUS_URL:-https://66rkpxcki4.execute-api.us-east-2.amazonaws.com/dev}"
TENANT="${EIGENTUNNEL_TENANT_ID:-field-test}"

if [ ! -f "$PACK/install.sh" ]; then
  echo "missing $PACK/install.sh" >&2
  exit 1
fi

# Ensure baked leaf name / overlay / gateway peer stay in place
printf '%s\n' "$NODE_ID" > "$PACK/leaf-name.txt"
printf '%s\n' "$OVERLAY" > "$PACK/overlay.txt"
if [ ! -f "$PACK/02-PUT-GATEWAY-PEER-HERE/peer.env" ]; then
  echo "missing pre-baked gateway peer at $PACK/02-PUT-GATEWAY-PEER-HERE/peer.env" >&2
  exit 1
fi

cd "$PACK"
./install.sh --name "$NODE_ID" --overlay "$OVERLAY" --force --no-wait

IDENTITY_KEY="$HOME/EigenTunnel/identity/identity.key"
if [ ! -f "$IDENTITY_KEY" ]; then
  echo "missing $IDENTITY_KEY after install" >&2
  exit 1
fi
# Rendezvous wants a short device key (32-byte). peer.env PQ blob is rejected.
PUB="$("$ROOT/bin/device-pubkey.py" "$IDENTITY_KEY")"
if [ -z "$PUB" ]; then
  echo "could not derive device public key from identity.key" >&2
  exit 1
fi

REGISTER_PY="$ROOT/register-public-peer.py"
echo "Registering public peer for node=$NODE_ID (private key stays on this Mac)…"
EIGENTUNNEL_RENDEZVOUS_URL="$API" \
EIGENTUNNEL_ACTIVATE_TOKEN="$TOKEN" \
EIGENTUNNEL_TENANT_ID="$TENANT" \
EIGENTUNNEL_NODE_ID="$NODE_ID" \
EIGENTUNNEL_PEER_ID="$NODE_ID" \
EIGENTUNNEL_DEVICE_PUBLIC_KEY="$PUB" \
python3 "$REGISTER_PY"
echo "Done. Public peer registered. Do not email peer.env or identity.key."
