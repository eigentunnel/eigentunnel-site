#!/bin/bash
# Shared settings for EigenTunnel EasyStart v4 (macOS). Sourced by the other scripts.
# Every value can be overridden from the environment (used only for side-by-side tests).
PAYLOAD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$PAYLOAD_DIR/node.conf"
# Test-only overrides (never shipped): lets a side-by-side test use another name/IP/port/root.
[ -r "$PAYLOAD_DIR/local-overrides.conf" ] && . "$PAYLOAD_DIR/local-overrides.conf"
NODE_NAME="${ET_NODE_NAME:-$NODE_NAME}"
OVERLAY="${ET_OVERLAY:-$OVERLAY}"
ROUTES="${ET_ROUTES:-$ROUTES}"
LISTEN_PORT="${ET_LISTEN_PORT:-$LISTEN_PORT}"
API_PORT="${ET_API_PORT:-$API_PORT}"
MTU="${ET_MTU:-$MTU}"
PARTNER_OVERLAY_IP="${ET_PARTNER_OVERLAY_IP:-$PARTNER_OVERLAY_IP}"
GATEWAY_OVERLAY_IP="${ET_GATEWAY_OVERLAY_IP:-$GATEWAY_OVERLAY_IP}"
# Install root (root-owned). v4 keeps everything here plus one LaunchDaemon plist.
ET_ROOT="${ET_ROOT:-/Library/Application Support/EigenTunnel}"
ET_LABEL="${ET_LABEL:-com.eigentunnel.leaf}"
ET_PLIST="/Library/LaunchDaemons/${ET_LABEL}.plist"
ET_BIN="$ET_ROOT/bin"
ET_IDENTITY="$ET_ROOT/identity"      # identity.key lives here, root-only (never sent)
ET_PUBLIC="$ET_ROOT/public"          # public peer file only
ET_CONFIG="$ET_ROOT/config/leaf.toml"
ET_LOGS="$ET_ROOT/logs"
ET_STATE="$ET_ROOT/state"
MONITOR_URL="http://127.0.0.1:${API_PORT}/"

env_val() { # env_val FILE KEY -> value without surrounding quotes
  sed -n "s/^$2=//p" "$1" | head -1 | sed "s/^'//; s/'\$//; s/^\"//; s/\"\$//"
}
