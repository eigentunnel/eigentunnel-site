#!/bin/bash
# EigenTunnel v4 self-test. Runs as the normal user (no password). Checks, in plain words:
#  1 service running   2 utun up with overlay address   3 handshake with the gateway
#  4 end-to-end relay pairing key with the test partner   5 leaf-to-leaf ping through the gateway
#  6 post-office check (local side: nothing unsealed leaves; gateway side is checked by support)
# Results: ~/Library/Logs/EigenTunnel/self-test-latest.{txt,json,html}. Optional non-secret report
# upload if payload/report.conf sets STATUS_PUT_URL (node name, pass/fail, timestamps only).
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
WAIT="${1:-60}"   # seconds to wait for handshake + pairing
OUTDIR="${ET_REPORT_DIR:-$HOME/Library/Logs/EigenTunnel}"; mkdir -p "$OUTDIR"
LOG="$ET_LOGS/leaf.log"; IP="${OVERLAY%/*}"
PT_NAME="$(env_val "$(dirname "${BASH_SOURCE[0]}")/partner-peer.env" EIGENTUNNEL_NODE_NAME)"
TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
since_start() { [ -r "$LOG" ] || return 0; awk '/"eigentunneld starting"/{buf=""} {buf=buf $0 "\n"} END{printf "%s", buf}' "$LOG"; }
declare -a NAMES STATUS DETAIL
add() { NAMES+=("$1"); STATUS+=("$2"); DETAIL+=("$3"); }

# 1 service
if pgrep -f "$ET_BIN/eigentunneld" >/dev/null 2>&1; then add "EigenTunnel service running" PASS "background service $ET_LABEL is running";
else add "EigenTunnel service running" FAIL "service is not running - double-click Start EigenTunnel again"; fi

# 2 utun
IF="$(cat "$ET_STATE/utun" 2>/dev/null)"
if [ -n "$IF" ] && /sbin/ifconfig "$IF" 2>/dev/null | grep -q "inet $IP "; then
  MTUV="$(/sbin/ifconfig "$IF" | sed -n 's/.*mtu \([0-9]*\).*/\1/p' | head -1)"
  add "Tunnel interface up with address" PASS "$IF has $IP (mtu $MTUV)"
else add "Tunnel interface up with address" FAIL "tunnel interface ${IF:-unknown} has no address $IP yet"; fi

# 3 handshake (wait up to WAIT s)
HS=FAIL; HSD="no answer from gateway 3.130.82.45 UDP 51820 - outbound UDP 51820 may be blocked (router/Starlink/firewall)"
end=$(( $(date +%s) + WAIT ))
while :; do
  S="$(since_start)"
  last_ok="$(printf '%s' "$S" | grep -n 'outbound peer session established' | tail -1 | cut -d: -f1)"
  last_bad="$(printf '%s' "$S" | grep -n 'closed by peer' | tail -1 | cut -d: -f1)"
  if [ -n "$last_ok" ] && { [ -z "$last_bad" ] || [ "$last_ok" -gt "$last_bad" ]; }; then HS=PASS; HSD="secure session with gateway aws-gateway established"; break; fi
  if [ -n "$last_bad" ]; then HS=WAIT; HSD="gateway answered but does not know this Mac's key yet (expected until support adds it; it keeps retrying by itself)"; fi
  [ "$(date +%s)" -ge "$end" ] && break; sleep 2
done
[ "$HS" = WAIT ] && HS=FAIL
add "Handshake with gateway" "$HS" "$HSD"

# 4 pairing key with partner (the node with the alphabetically smaller name logs the install)
PAIR=FAIL; PAIRD="no end-to-end key with $PT_NAME yet (needs gateway handshake, and $PT_NAME online and knowing this Mac's key)"
if [ "$HS" = PASS ]; then
  end=$(( $(date +%s) + WAIT ))
  while :; do
    if since_start | grep -q 'relay pair key installed from answer'; then PAIR=PASS; PAIRD="end-to-end relay key installed with $PT_NAME (gateway never holds it)"; break; fi
    [ "$(date +%s)" -ge "$end" ] && break
    ping -c 1 -t 2 "$PARTNER_OVERLAY_IP" >/dev/null 2>&1   # a packet nudges pairing
    sleep 2
  done
fi

# 5 leaf-to-leaf ping
if ping -c 5 -t 10 "$PARTNER_OVERLAY_IP" >"$OUTDIR/ping.txt" 2>&1; then
  RX="$(grep -o '[0-9]* packets received' "$OUTDIR/ping.txt")"; add_ping=PASS; PINGD="$PT_NAME ($PARTNER_OVERLAY_IP) answered through the gateway: $RX"
  [ "$PAIR" = FAIL ] && { PAIR=PASS; PAIRD="end-to-end key with $PT_NAME works (proven by sealed ping)"; }
else add_ping=FAIL; PINGD="no reply from $PT_NAME ($PARTNER_OVERLAY_IP)"; fi
add "Relay pairing key with test partner" "$PAIR" "$PAIRD"
add "Leaf-to-leaf ping through gateway" "$add_ping" "$PINGD"

# 6 post-office (local side)
HELD="$(since_start | grep -c 'packet held (post-office rule)')"
add "Post-office check (this Mac)" PASS "build 6c9fad6 fails closed: $HELD packet(s) to other leaves were held (not sent) while no end-to-end key existed. The gateway-side check (relay_envelope_drops) is done by support."

# write results
TXT="$OUTDIR/self-test-latest.txt"; JSON="$OUTDIR/self-test-latest.json"; HTML="$OUTDIR/self-test-latest.html"
{
  echo "EigenTunnel self-test - $NODE_NAME - $TS"
  for i in "${!NAMES[@]}"; do printf '%-5s %s: %s\n' "${STATUS[$i]}" "${NAMES[$i]}" "${DETAIL[$i]}"; done
} > "$TXT"
{
  printf '{"node_name":"%s","overlay":"%s","time_utc":"%s","checks":[' "$NODE_NAME" "$IP" "$TS"
  for i in "${!NAMES[@]}"; do [ "$i" -gt 0 ] && printf ','; printf '{"check":"%s","result":"%s"}' "${NAMES[$i]}" "${STATUS[$i]}"; done
  printf ']}\n'
} > "$JSON"
{
  echo "<!doctype html><meta charset=utf-8><meta http-equiv=refresh content=30><title>EigenTunnel self-test</title>"
  echo "<body style='font-family:-apple-system,Helvetica;max-width:760px;margin:30px auto'>"
  echo "<h2>EigenTunnel self-test: $NODE_NAME</h2><p>$TS (UTC) &middot; live monitor: <a href='$MONITOR_URL'>$MONITOR_URL</a></p><table cellpadding=8>"
  for i in "${!NAMES[@]}"; do c=green; [ "${STATUS[$i]}" = PASS ] || c=#b00; echo "<tr><td style='color:$c;font-weight:bold'>${STATUS[$i]}</td><td><b>${NAMES[$i]}</b><br>${DETAIL[$i]}</td></tr>"; done
  echo "</table><p style='color:#555'>No keys are in this report. Never send identity.key or peer.env.</p></body>"
} > "$HTML"
cat "$TXT"
# optional non-secret status upload
RC="$(dirname "${BASH_SOURCE[0]}")/report.conf"
if [ -r "$RC" ]; then . "$RC"; if [ -n "${STATUS_PUT_URL:-}" ]; then
  /usr/bin/curl -s -m 15 -X PUT -H 'content-type: application/json' --data-binary @"$JSON" "$STATUS_PUT_URL" >/dev/null && echo "(status report sent: node name + pass/fail only)"; fi; fi
grep -q '^FAIL' "$TXT" && exit 1 || exit 0
