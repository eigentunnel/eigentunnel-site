#!/bin/bash
# Print ONLY the node name and the two PUBLIC keys of this Mac, as one copy-paste block.
# Also copies the block to the clipboard and saves it to the Desktop (public only).
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
PUB="$ET_PUBLIC/peer.env"
if [ ! -r "$PUB" ]; then echo "No EigenTunnel key on this Mac yet. Double-click 'Start EigenTunnel' first."; exit 1; fi
N="$(env_val "$PUB" EIGENTUNNEL_NODE_NAME)"; K="$(env_val "$PUB" EIGENTUNNEL_PUBLIC_KEY_B64)"; M="$(env_val "$PUB" EIGENTUNNEL_KEM_KEY_B64)"
BLOCK="-----BEGIN EIGENTUNNEL PUBLIC KEY-----
node_name=$N
public_key=$K
public_kem_key=$M
-----END EIGENTUNNEL PUBLIC KEY-----"
echo
echo "=== Your EigenTunnel PUBLIC key (safe to send) ==="
echo
echo "$BLOCK"
echo
if command -v pbcopy >/dev/null 2>&1; then printf '%s\n' "$BLOCK" | pbcopy && echo "(This block is already copied. In your reply email, just Paste.)"; fi
OUT="${ET_PUBKEY_OUT:-$HOME/Desktop/EigenTunnel-public-key-$N.txt}"
printf '%s\n' "$BLOCK" > "$OUT" 2>/dev/null && echo "(Also saved to: $OUT)"
echo
echo "!!  NEVER send any other EigenTunnel file. Never send identity.key, peer.env, node.env,"
echo "!!  or anything from the 'identity' folder. Only the block above between BEGIN and END."
