#!/bin/bash
# EigenTunnel EasyStart v4 - privileged part. Run as root (Start EigenTunnel.command asks for the
# Mac password once through the standard macOS dialog and runs this).
#   install-and-start.sh --user NAME
# Steps: remove old installs -> copy binaries -> make a NEW key on this Mac -> write config ->
#        install LaunchDaemon -> start -> wait for utun address.
set -euo pipefail
TARGET_USER=""
while [ $# -gt 0 ]; do case "$1" in --user) TARGET_USER="$2"; shift 2 ;; *) echo "unknown arg $1" >&2; exit 2 ;; esac; done
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$HERE/common.sh"
[ "$(id -u)" -eq 0 ] || { echo "needs admin rights" >&2; exit 1; }
[ -n "$TARGET_USER" ] || TARGET_USER="${SUDO_USER:-}"
say() { echo "[$(date +%H:%M:%S)] $*"; }

say "1/6 Removing any old EigenTunnel install"
"$HERE/uninstall-old.sh" --user "$TARGET_USER" ${ET_UNINSTALL_SCOPE:+--scope "$ET_UNINSTALL_SCOPE"}

say "2/6 Installing programs to $ET_ROOT"
mkdir -p "$ET_BIN" "$ET_IDENTITY" "$ET_PUBLIC" "$(dirname "$ET_CONFIG")" "$ET_LOGS" "$ET_STATE" "$ET_ROOT/run"
for b in eigentunneld eigentunnel-perf-identity; do
  install -m 755 "$HERE/bin/$b" "$ET_BIN/$b"
  xattr -c "$ET_BIN/$b" 2>/dev/null || true    # drop download quarantine on our own copy
done
for f in common.sh node.conf leaf-run.sh self-test.sh show-public-key.sh uninstall-old.sh gateway-peer.env partner-peer.env; do
  install -m 755 "$HERE/$f" "$ET_ROOT/run/$f"
done
[ -r "$HERE/local-overrides.conf" ] && install -m 644 "$HERE/local-overrides.conf" "$ET_ROOT/run/local-overrides.conf"
[ -r "$HERE/report.conf" ] && install -m 644 "$HERE/report.conf" "$ET_ROOT/run/report.conf"
chown -R root:wheel "$ET_ROOT"; chmod 755 "$ET_ROOT" "$ET_LOGS" "$ET_STATE" "$ET_PUBLIC"
"$ET_BIN/eigentunneld" --version >/dev/null 2>&1 || "$ET_BIN/eigentunneld" --help >/dev/null 2>&1 || {
  echo "The EigenTunnel program would not run on this Mac ($(uname -m))." >&2; exit 1; }

say "3/6 Making a NEW key for $NODE_NAME (private key stays on this Mac, readable by admin only)"
rm -rf "$ET_IDENTITY"; mkdir -p "$ET_IDENTITY"; chmod 700 "$ET_IDENTITY"
"$ET_BIN/eigentunnel-perf-identity" --node-name "$NODE_NAME" --overlay-address "$OVERLAY" \
  --listen "0.0.0.0:${LISTEN_PORT}" --output-dir "$ET_IDENTITY" --force >/dev/null
chmod 600 "$ET_IDENTITY/identity.key"
PUBK="$(env_val "$ET_IDENTITY/peer.env" EIGENTUNNEL_PUBLIC_KEY_B64)"
KEMK="$(env_val "$ET_IDENTITY/peer.env" EIGENTUNNEL_KEM_KEY_B64)"
[ -n "$PUBK" ] && [ -n "$KEMK" ] || { echo "key generation failed" >&2; exit 1; }
# Public peer file = node name, overlay address, two PUBLIC keys. Nothing else.
{ echo "EIGENTUNNEL_NODE_NAME=$NODE_NAME"; echo "EIGENTUNNEL_NODE_ADDRESS=$OVERLAY"
  echo "EIGENTUNNEL_PUBLIC_KEY_B64=$PUBK"; echo "EIGENTUNNEL_KEM_KEY_B64=$KEMK"; } > "$ET_PUBLIC/peer.env"
chmod 644 "$ET_PUBLIC/peer.env"

say "4/6 Writing leaf config (gateway 3.130.82.45:51820, test partner leaf)"
GW="$HERE/gateway-peer.env"; PT="$HERE/partner-peer.env"
PT_NAME="$(env_val "$PT" EIGENTUNNEL_NODE_NAME)"
cat > "$ET_CONFIG" <<CFG
# EigenTunnel v4 leaf ($NODE_NAME). Outbound only: the gateway never dials this Mac.
[node]
name = "$NODE_NAME"
listen = "0.0.0.0:${LISTEN_PORT}"
address = "$OVERLAY"
key_path = "$ET_IDENTITY/identity.key"
algorithm = "ml-kem-768"
sign = "ml-dsa-65"
api_enabled = true
api_addr = "127.0.0.1:${API_PORT}"

[[peer]]
name = "$(env_val "$GW" EIGENTUNNEL_NODE_NAME)"
mode = "gateway_client"
endpoint = "$(env_val "$GW" EIGENTUNNEL_PUBLIC_ENDPOINT)"
public_key = "$(env_val "$GW" EIGENTUNNEL_PUBLIC_KEY_B64)"
kem_key = "$(env_val "$GW" EIGENTUNNEL_KEM_KEY_B64)"
allowed_ips = ["${GATEWAY_OVERLAY_IP}/32", "${PARTNER_OVERLAY_IP}/32"]
key_rotation_secs = 3600

# Test partner leaf. Traffic to it is sealed end to end (ETRL); the gateway only forwards envelopes.
[[peer]]
name = "$PT_NAME"
mode = "relay_leaf"
public_key = "$(env_val "$PT" EIGENTUNNEL_PUBLIC_KEY_B64)"
kem_key = "$(env_val "$PT" EIGENTUNNEL_KEM_KEY_B64)"
allowed_ips = []
CFG
chmod 644 "$ET_CONFIG"

say "5/6 Starting EigenTunnel as a background service ($ET_LABEL)"
cat > "$ET_PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$ET_LABEL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$ET_ROOT/run/leaf-run.sh</string></array>
  <key>EnvironmentVariables</key><dict>
    <key>ET_ROOT</key><string>$ET_ROOT</string><key>ET_LABEL</key><string>$ET_LABEL</string>
    <key>ET_NODE_NAME</key><string>$NODE_NAME</string><key>ET_OVERLAY</key><string>$OVERLAY</string>
    <key>ET_ROUTES</key><string>$ROUTES</string><key>ET_API_PORT</key><string>$API_PORT</string>
    <key>ET_LISTEN_PORT</key><string>$LISTEN_PORT</string><key>ET_MTU</key><string>$MTU</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$ET_LOGS/launchd.log</string>
  <key>StandardErrorPath</key><string>$ET_LOGS/launchd.log</string>
</dict></plist>
PL
chown root:wheel "$ET_PLIST"; chmod 644 "$ET_PLIST"
launchctl bootout "system/$ET_LABEL" 2>/dev/null || true
launchctl bootstrap system "$ET_PLIST"
launchctl enable "system/$ET_LABEL" 2>/dev/null || true

say "6/6 Waiting for the tunnel interface to get its address"
for _ in $(seq 1 40); do [ -s "$ET_STATE/utun" ] && break; sleep 0.5; done
if [ -s "$ET_STATE/utun" ]; then
  IF="$(cat "$ET_STATE/utun")"; say "Tunnel interface $IF is up with ${OVERLAY%/*}"
else
  say "Tunnel interface not up yet; see $ET_LOGS/leaf-run.log"
fi
say "Install finished. Monitor: $MONITOR_URL"
