#!/bin/bash
# Run by launchd as root (LaunchDaemon). Starts eigentunneld, then gives the utun it creates
# its overlay address, MTU and routes (the daemon leaves address setup to the OS).
# launchd owns the process: no nohup, no Terminal window needs to stay open.
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
LOG="$ET_LOGS/leaf.log"
mkdir -p "$ET_LOGS" "$ET_STATE"; touch "$LOG"; chmod 644 "$LOG"
note() { printf '%s leaf-run: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >> "$ET_LOGS/leaf-run.log"; }
chmod 644 "$ET_LOGS/leaf-run.log" 2>/dev/null || true
rm -f "$ET_STATE/utun"

"$ET_BIN/eigentunneld" --config "$ET_CONFIG" >> "$LOG" 2>&1 &
DPID=$!
trap 'kill -TERM $DPID 2>/dev/null; wait $DPID; exit 0' TERM INT
note "started eigentunneld pid=$DPID"

IP="${OVERLAY%/*}"
IFACE=""
for _ in $(seq 1 60); do
  kill -0 $DPID 2>/dev/null || break
  IFACE="$(/usr/bin/curl -s -m 1 "http://127.0.0.1:${API_PORT}/v1/status" | grep -o '"tunnel_interface":"utun[0-9]*"' | grep -o 'utun[0-9]*')"
  [ -n "$IFACE" ] && break
  sleep 0.5
done
if [ -z "$IFACE" ]; then
  # fallback: the daemon logs the utun name when it opens it
  IFACE="$(grep 'opened macOS utun interface' "$LOG" | tail -1 | grep -o '"interface":"utun[0-9]*"' | grep -o 'utun[0-9]*')"
fi
if [ -n "$IFACE" ]; then
  /sbin/ifconfig "$IFACE" inet "$IP" "$GATEWAY_OVERLAY_IP" netmask 255.255.255.255 mtu "$MTU" up
  IFS=',' read -r -a RLIST <<< "$ROUTES"
  for r in "${RLIST[@]}"; do
    r="$(echo "$r" | tr -d ' ')"; [ -n "$r" ] || continue
    /sbin/route -q -n delete -net "$r" -interface "$IFACE" >/dev/null 2>&1 || true
    if /sbin/route -q -n add -net "$r" -interface "$IFACE" >/dev/null 2>&1; then note "route $r -> $IFACE"; else note "route add failed: $r"; fi
  done
  echo "$IFACE" > "$ET_STATE/utun"; chmod 644 "$ET_STATE/utun"
  note "configured $IFACE inet $IP -> $GATEWAY_OVERLAY_IP mtu $MTU routes $ROUTES"
else
  note "no utun interface seen (daemon exited or API not up); launchd will restart"
fi
wait $DPID
RC=$?
note "eigentunneld exited rc=$RC"
exit $RC
