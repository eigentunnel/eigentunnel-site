#!/bin/bash
cd "$(dirname "$0")" || exit 1
"$(pwd)/payload/show-public-key.sh"
echo; read -r -p "Press Return to close..." _
