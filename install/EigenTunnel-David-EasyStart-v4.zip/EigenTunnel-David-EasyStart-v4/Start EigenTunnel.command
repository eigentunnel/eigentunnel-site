#!/bin/bash
# EigenTunnel EasyStart v4 - double-click this. It asks for your Mac password once, then:
# removes any old EigenTunnel, makes a new key on this Mac, starts the tunnel, tests it,
# opens the monitor, and shows your PUBLIC key.
cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"; P="$ROOT/payload"
# shellcheck disable=SC1091
. "$P/common.sh"
clear 2>/dev/null
echo "=============================================="
echo "   EigenTunnel - Start ($NODE_NAME)"
echo "=============================================="
echo
echo "A macOS window will ask for your Mac password. That lets EigenTunnel"
echo "set up its secure network connection. Type your normal Mac login password."
echo
LOGF="$(mktemp -t eigentunnel-install)"
if ! /usr/bin/osascript - "$P/install-and-start.sh" "$(id -un)" "$LOGF" <<'OSA'
on run argv
  set s to item 1 of argv
  set u to item 2 of argv
  set l to item 3 of argv
  do shell script "/bin/bash " & quoted form of s & " --user " & quoted form of u & " > " & quoted form of l & " 2>&1" with prompt "EigenTunnel needs your Mac password to set up its secure tunnel." with administrator privileges
end run
OSA
then
  cat "$LOGF"
  echo
  echo "Setup did not finish (password cancelled, or an error above)."
  echo "Take a screenshot of this window and send it to support@eigentunnel.com."
  read -r -p "Press Return to close..." _; exit 1
fi
cat "$LOGF"
echo
# Hands-off public key delivery (only if this package has a public-key drop configured).
if [ -r "$P/peer-drop.conf" ]; then
  # shellcheck disable=SC1091
  . "$P/peer-drop.conf"
  PUBF="$ET_PUBLIC/peer.env"
  if [ -n "${PEER_DROP_URL:-}" ] && [ "$(grep -cvE '^EIGENTUNNEL_(NODE_NAME|NODE_ADDRESS|PUBLIC_KEY_B64|KEM_KEY_B64)=' "$PUBF")" = 0 ]; then
    if /usr/bin/curl -sf -m 20 -X PUT -H 'content-type: text/plain' --data-binary @"$PUBF" "$PEER_DROP_URL" >/dev/null; then
      echo "Your PUBLIC key was sent to EigenTunnel support automatically (public key only)."
    else
      echo "Could not send the public key automatically; please use the copy below."
    fi
  fi
fi
echo "Opening the EigenTunnel monitor in your browser: $MONITOR_URL"
open "$MONITOR_URL" 2>/dev/null
echo
echo "Running the self-test (up to about 2 minutes)..."
echo
"$ET_ROOT/run/self-test.sh" 60
open "$HOME/Library/Logs/EigenTunnel/self-test-latest.html" 2>/dev/null
"$ET_ROOT/run/show-public-key.sh"
echo
echo "EigenTunnel keeps running in the background (also after a restart). You can close this window."
read -r -p "Press Return to close..." _
