#!/bin/bash
cd "$(dirname "$0")" || exit 1
"$(pwd)/payload/self-test.sh" 30
open "$HOME/Library/Logs/EigenTunnel/self-test-latest.html" 2>/dev/null
echo; read -r -p "Press Return to close..." _
