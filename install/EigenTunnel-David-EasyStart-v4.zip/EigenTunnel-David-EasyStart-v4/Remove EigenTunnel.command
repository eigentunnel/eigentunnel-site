#!/bin/bash
# Removes EigenTunnel completely (old versions and this one). Asks for your Mac password.
cd "$(dirname "$0")" || exit 1
P="$(pwd)/payload"
echo "This will stop EigenTunnel and delete it (including its keys) from this Mac:"
"$P/uninstall-old.sh" --dry-run
read -r -p "Type YES and press Return to remove: " A
[ "$A" = "YES" ] || { echo "Nothing removed."; exit 0; }
/usr/bin/osascript - "$P/uninstall-old.sh" "$(id -un)" <<'OSA'
on run argv
  do shell script "/bin/bash " & quoted form of (item 1 of argv) & " --user " & quoted form of (item 2 of argv) with prompt "EigenTunnel needs your Mac password to remove itself." with administrator privileges
end run
OSA
echo "Done."; read -r -p "Press Return to close..." _
