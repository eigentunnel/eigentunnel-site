#!/usr/bin/env bash
# EigenTunnel macOS leaf pack — one command for every leaf-side task.
#
# The leaf user runs ./install.sh and sends 01-SEND-THIS-FILE/peer.env.
# This script does not clone or fast-forward a repository.
#
# Optional core installer (parallel Eigentunnel core work):
#   scripts/install/eigen-leaf-macos.sh
# When that file exists, it is invoked with the environment below and this
# pack still enforces the send-folder contract. Otherwise the steps below
# run in place (vendored copy).
#
#   EIGEN_HOME              default ~/EigenTunnel
#   EIGEN_PACK_DIR          this folder
#   EIGEN_SEND_DIR          .../01-SEND-THIS-FILE
#   EIGEN_GATEWAY_INBOX     .../02-PUT-GATEWAY-PEER-HERE
#   EIGEN_NODE_NAME         leaf name (leaf-name.txt)
#   EIGEN_OVERLAY           overlay CIDR (overlay.txt)
#   EIGEN_LEAF_NO_WAIT      1 = do not block for the gateway file
#   EIGEN_LEAF_WAIT_SECS    seconds to wait; 0 = until the file appears
#   EIGEN_LEAF_VENDOR_ONLY  1 = do not delegate to a core installer
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$PACK_DIR/../.." && pwd)"
EIGEN_HOME="${EIGEN_HOME:-$HOME/EigenTunnel}"
SEND_DIR="${EIGEN_SEND_DIR:-$PACK_DIR/01-SEND-THIS-FILE}"
GATEWAY_INBOX="${EIGEN_GATEWAY_INBOX:-$PACK_DIR/02-PUT-GATEWAY-PEER-HERE}"
HOME_SEND_DIR="$EIGEN_HOME/01-SEND-THIS-FILE"
HOME_GATEWAY_DIR="$EIGEN_HOME/02-PUT-GATEWAY-PEER-HERE"
IDENTITY_DIR="$EIGEN_HOME/identity"
CONFIG_PATH="$EIGEN_HOME/config/leaf.toml"
LOG_DIR="$EIGEN_HOME/logs"
UDP_PORT="${EIGEN_UDP_PORT:-51820}"
NO_WAIT=0
WAIT_SECS="${EIGEN_LEAF_WAIT_SECS:-0}"
FORCE=0
NODE_NAME="${EIGEN_NODE_NAME:-}"
OVERLAY="${EIGEN_OVERLAY:-}"

usage() {
  cat <<'EOF'
EigenTunnel leaf install (one command).

  ./install.sh

Writes public 01-SEND-THIS-FILE/peer.env and, when a gateway peer file is in
02-PUT-GATEWAY-PEER-HERE/, starts the outbound leaf. Does not clone a repository.

Operator flags (the leaf user can ignore these):
  --name NAME       node name (default: leaf-name.txt, else leaf)
  --overlay CIDR    overlay address (default: overlay.txt, else 10.66.0.1/24)
  --no-wait         publish peer.env and exit if no gateway file is present
  --wait-secs N     stop waiting after N seconds (0 waits until the file appears)
  --force           generate a new identity
EOF
}

read_one_line_file() {
  local file="$1"
  [ -f "$file" ] || return 1
  local line
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [ -z "$line" ] && continue
    case "$line" in
      \#*) continue ;;
    esac
    printf '%s\n' "$line"
    return 0
  done < "$file"
  return 1
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --name) NODE_NAME="$2"; shift 2 ;;
    --overlay) OVERLAY="$2"; shift 2 ;;
    --no-wait) NO_WAIT=1; shift ;;
    --wait-secs) WAIT_SECS="$2"; shift 2 ;;
    --force) FORCE=1; shift ;;
    --help|-h) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 1 ;;
  esac
done

if [ "${EIGEN_LEAF_NO_WAIT:-0}" = "1" ]; then
  NO_WAIT=1
fi

if [ -z "$NODE_NAME" ]; then
  NODE_NAME="$(read_one_line_file "$PACK_DIR/leaf-name.txt" || true)"
fi
NODE_NAME="${NODE_NAME:-leaf}"

if [ -z "$OVERLAY" ]; then
  OVERLAY="$(read_one_line_file "$PACK_DIR/overlay.txt" || true)"
fi
OVERLAY="${OVERLAY:-10.66.0.1/24}"

if ! printf '%s' "$NODE_NAME" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$'; then
  echo "Invalid leaf name: $NODE_NAME" >&2
  exit 1
fi
if ! printf '%s' "$OVERLAY" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$'; then
  echo "Invalid overlay CIDR: $OVERLAY" >&2
  exit 1
fi

if [ "$(uname -s)" != "Darwin" ] && [ "${EIGEN_LEAF_ALLOW_NON_MACOS:-0}" != "1" ]; then
  echo "This pack runs on a Mac leaf." >&2
  exit 1
fi

# Optional cloud pack URL from POST /v1/eigentunnel/leaf-pack.
# Absent URL keeps this vendored pack. The stub does not write identity.key.
if [ -n "${EIGEN_LEAF_PACK_URL:-}" ]; then
  "$PACK_DIR/fetch-leaf-pack.sh"
fi

mkdir -p "$EIGEN_HOME" "$SEND_DIR" "$GATEWAY_INBOX" "$HOME_SEND_DIR" "$HOME_GATEWAY_DIR" \
  "$IDENTITY_DIR" "$EIGEN_HOME/config" "$LOG_DIR"
LOG="$LOG_DIR/install.log"
touch "$LOG"

log() { printf '%s\n' "$*" | tee -a "$LOG" >&2; }

retire_one() {
  local path="$1"
  [ -e "$path" ] || [ -L "$path" ] || return 0
  local resolved=""
  if [ -d "$path" ]; then
    resolved="$(cd "$path" && pwd)"
  fi
  case "$resolved" in
    "$EIGEN_HOME"|"$PACK_DIR"|"$REPO_DIR")
      log "leave in place: $path"
      return 0
      ;;
  esac
  local trash="${EIGEN_TRASH_DIR:-$HOME/.Trash}"
  mkdir -p "$trash"
  local dest="$trash/$(basename "$path")-retired-$(date -u +%Y%m%dT%H%M%SZ)"
  mv "$path" "$dest"
  log "retired legacy directory $path -> $dest"
}

retire_legacy_dirs() {
  local name
  for name in FreeQ freeQ FREEQ; do
    retire_one "$HOME/$name"
  done
}

find_core_installer() {
  if [ "${EIGEN_LEAF_VENDOR_ONLY:-0}" = "1" ]; then
    return 1
  fi
  local candidate
  local candidates=()
  if [ -n "${EIGENTUNNEL_CORE:-}" ]; then
    candidates+=("$EIGENTUNNEL_CORE/scripts/install/eigen-leaf-macos.sh")
  fi
  candidates+=(
    "$REPO_DIR/../eigentunnel-core/scripts/install/eigen-leaf-macos.sh"
    "$REPO_DIR/../eigentunnel-core-dev/scripts/install/eigen-leaf-macos.sh"
  )
  for candidate in "${candidates[@]}"; do
    if [ -f "$candidate" ] && [ "$candidate" != "$PACK_DIR/install.sh" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

find_identity_bin() {
  if [ -n "${EIGEN_IDENTITY_BIN:-}" ] && [ -x "$EIGEN_IDENTITY_BIN" ]; then
    printf '%s\n' "$EIGEN_IDENTITY_BIN"
    return 0
  fi
  local name path
  for name in eigen-perf-identity eigentunnel-perf-identity freeq-perf-identity; do
    if path="$(command -v "$name" 2>/dev/null)"; then
      printf '%s\n' "$path"
      return 0
    fi
  done
  local bundled
  for bundled in "$PACK_DIR/bin/eigen-perf-identity" "$EIGEN_HOME/bin/eigen-perf-identity"; do
    if [ -x "$bundled" ]; then
      printf '%s\n' "$bundled"
      return 0
    fi
  done
  return 1
}

find_daemon_bin() {
  if [ -n "${EIGEN_DAEMON_BIN:-}" ] && [ -x "$EIGEN_DAEMON_BIN" ]; then
    printf '%s\n' "$EIGEN_DAEMON_BIN"
    return 0
  fi
  local name path
  for name in eigentunneld eigen-leaf freeqd; do
    if path="$(command -v "$name" 2>/dev/null)"; then
      printf '%s\n' "$path"
      return 0
    fi
  done
  local bundled
  for bundled in "$PACK_DIR/bin/eigentunneld" "$EIGEN_HOME/bin/eigentunneld"; do
    if [ -x "$bundled" ]; then
      printf '%s\n' "$bundled"
      return 0
    fi
  done
  return 1
}

discover_raw_peer() {
  local candidate dir
  local files=(
    "$IDENTITY_DIR/peer.env"
    "$SEND_DIR/peer.env"
    "$HOME_SEND_DIR/peer.env"
    "$EIGEN_HOME/peer.env"
  )
  for candidate in "${files[@]}"; do
    if [ -f "$candidate" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  for dir in "$IDENTITY_DIR" "$EIGEN_HOME"; do
    [ -d "$dir" ] || continue
    for candidate in "$dir"/*-peer.env; do
      [ -f "$candidate" ] || continue
      printf '%s\n' "$candidate"
      return 0
    done
  done
  return 1
}

publish_peer_env() {
  local src="$1"
  local tmp
  tmp="$(mktemp)"
  awk '
    function emit(rest, val,    ek, fk) {
      ek = "EIGEN_" rest
      fk = "FREEQ_" rest
      if (!(ek in seen)) { seen[ek] = 1; print ek "=" val }
      if (!(fk in seen)) { seen[fk] = 1; print fk "=" val }
    }
    {
      line = $0
      sub(/\r$/, "", line)
      if (line ~ /^[[:space:]]*$/) next
      if (line ~ /^[[:space:]]*#/) next
      eq = index(line, "=")
      if (eq == 0) next
      key = substr(line, 1, eq - 1)
      val = substr(line, eq + 1)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", key)
      lk = tolower(key)
      if (lk ~ /private|secret|password|identity/) next
      if (key ~ /^EIGEN_/) { emit(substr(key, 7), val); next }
      if (key ~ /^FREEQ_/) { emit(substr(key, 7), val); next }
      if (!(key in seen)) { seen[key] = 1; print key "=" val }
    }
  ' "$src" > "$tmp"
  if ! grep -Eq '^(EIGEN_PUBLIC_KEY_B64|FREEQ_PUBLIC_KEY_B64)=.+' "$tmp"; then
    echo "Identity tool did not produce a public key." >&2
    rm -f "$tmp"
    exit 1
  fi
  if ! grep -Eq '^(EIGEN_KEM_KEY_B64|FREEQ_KEM_KEY_B64)=.+' "$tmp"; then
    echo "Identity tool did not produce a KEM key." >&2
    rm -f "$tmp"
    exit 1
  fi
  chmod 644 "$tmp"
  cp "$tmp" "$SEND_DIR/peer.env"
  cp "$tmp" "$HOME_SEND_DIR/peer.env"
  cp "$tmp" "$IDENTITY_DIR/peer.env"
  rm -f "$tmp"
  chmod 644 "$SEND_DIR/peer.env" "$HOME_SEND_DIR/peer.env" "$IDENTITY_DIR/peer.env"
}

assert_send_dir_clean() {
  local dir f base
  for dir in "$SEND_DIR" "$HOME_SEND_DIR"; do
    [ -d "$dir" ] || continue
    for f in "$dir"/*; do
      [ -e "$f" ] || continue
      base="$(basename "$f")"
      case "$base" in
        *.key|identity.key|*.pem)
          echo "Refusing to leave a private key in the send folder: $f" >&2
          exit 1
          ;;
      esac
    done
  done
}

env_value() {
  local file="$1" key="$2" line val
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      "$key"=*)
        val="${line#*=}"
        if [ "${#val}" -ge 2 ]; then
          local first last
          first="${val%"${val#?}"}"
          last="${val#"${val%?}"}"
          if [ "$first" = "$last" ] && { [ "$first" = "'" ] || [ "$first" = '"' ]; }; then
            val="${val:1:${#val}-2}"
          fi
        fi
        printf '%s\n' "$val"
        return 0
        ;;
    esac
  done < "$file"
  return 1
}

env_value_any() {
  local file="$1" key val
  shift
  for key in "$@"; do
    if val="$(env_value "$file" "$key")"; then
      printf '%s\n' "$val"
      return 0
    fi
  done
  return 1
}

toml_quote() {
  case "$1" in
    *\"*|*'\'*|*$'\n'*)
      echo "Refusing to write an unsafe config value." >&2
      exit 1
      ;;
  esac
  printf '"%s"' "$1"
}

overlay_host() {
  printf '%s\n' "${1%%/*}"
}

# Overlay route inside the tunnel (allowed_ips). Not a security-group admission.
overlay_network() {
  local addr="$1"
  local ip="${addr%%/*}"
  local plen="${addr##*/}"
  if [ "$plen" = "24" ]; then
    printf '%s\n' "${ip%.*}.0/24"
  else
    printf '%s\n' "${ip}/32"
  fi
}

find_gateway_peer() {
  local dir f
  for dir in "$GATEWAY_INBOX" "$HOME_GATEWAY_DIR"; do
    [ -d "$dir" ] || continue
    if [ -f "$dir/peer.env" ]; then
      printf '%s\n' "$dir/peer.env"
      return 0
    fi
    for f in "$dir"/*-peer.env; do
      [ -f "$f" ] || continue
      printf '%s\n' "$f"
      return 0
    done
  done
  return 1
}

write_leaf_config() {
  local gateway_peer="$1"
  local gw_name gw_endpoint gw_pub gw_kem allowed
  gw_name="$(env_value_any "$gateway_peer" EIGEN_NODE_NAME FREEQ_NODE_NAME || true)"
  gw_endpoint="$(env_value_any "$gateway_peer" EIGEN_PUBLIC_ENDPOINT FREEQ_PUBLIC_ENDPOINT || true)"
  gw_pub="$(env_value_any "$gateway_peer" EIGEN_PUBLIC_KEY_B64 FREEQ_PUBLIC_KEY_B64 || true)"
  gw_kem="$(env_value_any "$gateway_peer" EIGEN_KEM_KEY_B64 FREEQ_KEM_KEY_B64 || true)"
  gw_name="${gw_name:-gateway}"
  if [ -z "$gw_endpoint" ] || [ -z "$gw_pub" ] || [ -z "$gw_kem" ]; then
    echo "Gateway peer file is missing endpoint or public keys: $gateway_peer" >&2
    exit 1
  fi
  allowed="$(overlay_network "$OVERLAY")"
  local gw_addr=""
  gw_addr="$(env_value_any "$gateway_peer" EIGEN_NODE_ADDRESS FREEQ_NODE_ADDRESS || true)"
  local allowed_list
  allowed_list="$(toml_quote "$allowed")"
  if [ -n "$gw_addr" ]; then
    local gw32
    gw32="$(overlay_host "$gw_addr")/32"
    if [ "$gw32" != "$allowed" ]; then
      allowed_list="$allowed_list, $(toml_quote "$gw32")"
    fi
  fi
  if [ -f "$PACK_DIR/remote-overlays.txt" ]; then
    local extra
    while IFS= read -r extra || [ -n "$extra" ]; do
      extra="${extra#"${extra%%[![:space:]]*}"}"
      extra="${extra%"${extra##*[![:space:]]}"}"
      [ -z "$extra" ] && continue
      case "$extra" in \#*) continue ;; esac
      allowed_list="$allowed_list, $(toml_quote "$extra")"
    done < "$PACK_DIR/remote-overlays.txt"
  fi
  cat > "$CONFIG_PATH" <<EOF
# Outbound leaf. The gateway never dials this node.
[node]
name = $(toml_quote "$NODE_NAME")
listen = $(toml_quote "0.0.0.0:${UDP_PORT}")
address = $(toml_quote "$OVERLAY")
key_path = $(toml_quote "$IDENTITY_DIR/identity.key")
algorithm = "ml-kem-768"
sign = "ml-dsa-65"
api_enabled = true
api_addr = "127.0.0.1:6789"

[[peer]]
name = $(toml_quote "$gw_name")
mode = "gateway_client"
endpoint = $(toml_quote "$gw_endpoint")
public_key = $(toml_quote "$gw_pub")
kem_key = $(toml_quote "$gw_kem")
allowed_ips = [${allowed_list}]
key_rotation_secs = 3600
EOF
  log "wrote $CONFIG_PATH (mode=gateway_client)"
}

start_leaf() {
  local bin
  if ! bin="$(find_daemon_bin)"; then
    echo "Gateway file is present, but no EigenTunnel leaf daemon is on PATH." >&2
    echo "peer.env is ready to send. The tunnel was not started." >&2
    exit 1
  fi
  local pidfile="$EIGEN_HOME/leaf.pid"
  if [ -f "$pidfile" ]; then
    local old
    old="$(cat "$pidfile" 2>/dev/null || true)"
    if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
      log "leaf already running pid=$old"
      return 0
    fi
  fi
  log "starting $bin --config $CONFIG_PATH"
  # shellcheck disable=SC2094
  "$bin" --config "$CONFIG_PATH" >>"$LOG" 2>&1 &
  echo $! > "$pidfile"
  log "leaf pid $(cat "$pidfile")"
}

generate_identity() {
  local bin
  if [ "$FORCE" -eq 0 ] && [ -f "$IDENTITY_DIR/identity.key" ] && discover_raw_peer >/dev/null; then
    log "reusing existing identity in $IDENTITY_DIR"
    return 0
  fi
  if ! bin="$(find_identity_bin)"; then
    echo "No EigenTunnel identity tool on PATH." >&2
    echo "Install the EigenTunnel leaf release, or set EIGEN_IDENTITY_BIN." >&2
    echo "Do not clone a private repository on this Mac." >&2
    exit 1
  fi
  if [ "$FORCE" -eq 1 ]; then
    rm -f "$IDENTITY_DIR/identity.key" "$IDENTITY_DIR/peer.env" "$IDENTITY_DIR"/*-peer.env
  fi
  log "generating identity with $bin"
  "$bin" \
    --node-name "$NODE_NAME" \
    --overlay-address "$OVERLAY" \
    --listen "0.0.0.0:${UDP_PORT}" \
    --output-dir "$IDENTITY_DIR" \
    --force
  if [ ! -f "$IDENTITY_DIR/identity.key" ]; then
    echo "Identity tool did not write $IDENTITY_DIR/identity.key" >&2
    exit 1
  fi
  chmod 700 "$IDENTITY_DIR"
  chmod 600 "$IDENTITY_DIR/identity.key"
}

wait_for_gateway_peer() {
  local found start now
  if found="$(find_gateway_peer)"; then
    printf '%s\n' "$found"
    return 0
  fi
  if [ "$NO_WAIT" -eq 1 ]; then
    return 1
  fi
  log "Waiting for the gateway file in 02-PUT-GATEWAY-PEER-HERE/ (leave this window open)."
  start="$(date +%s)"
  while true; do
    if found="$(find_gateway_peer)"; then
      printf '%s\n' "$found"
      return 0
    fi
    if [ "$WAIT_SECS" -gt 0 ]; then
      now="$(date +%s)"
      if [ $((now - start)) -ge "$WAIT_SECS" ]; then
        return 1
      fi
    fi
    sleep 1
  done
}

banner() {
  cat <<EOF

========================================
EigenTunnel leaf
Send ONLY:
  $SEND_DIR/peer.env
Never send identity.key
========================================
EOF
}

export EIGEN_HOME EIGEN_PACK_DIR="$PACK_DIR" EIGEN_SEND_DIR="$SEND_DIR"
export EIGEN_GATEWAY_INBOX="$GATEWAY_INBOX" EIGEN_NODE_NAME="$NODE_NAME" EIGEN_OVERLAY="$OVERLAY"
export EIGEN_LEAF_NO_WAIT="$NO_WAIT" EIGEN_LEAF_WAIT_SECS="$WAIT_SECS"
export EIGEN_UDP_PORT="$UDP_PORT"

main() {
  log "=== EigenTunnel leaf install ==="
  log "pack=$PACK_DIR home=$EIGEN_HOME name=$NODE_NAME overlay=$OVERLAY"
  retire_legacy_dirs

  local core=""
  local delegated=0
  if core="$(find_core_installer)"; then
    log "delegating leaf work to $core"
    if [ -x "$core" ]; then
      "$core"
    else
      bash "$core"
    fi
    delegated=1
  fi
  if [ "$delegated" -eq 0 ] || { [ ! -f "$IDENTITY_DIR/identity.key" ] && ! discover_raw_peer >/dev/null; }; then
    generate_identity
  fi

  local raw=""
  if ! raw="$(discover_raw_peer)"; then
    echo "No public peer file was produced." >&2
    exit 1
  fi
  publish_peer_env "$raw"
  assert_send_dir_clean
  banner

  if [ "$delegated" -eq 1 ]; then
    log "core installer finished; peer.env is in the send folder"
    return 0
  fi

  local gateway=""
  if gateway="$(wait_for_gateway_peer)"; then
    log "gateway peer $gateway"
    write_leaf_config "$gateway"
    start_leaf
    log "leaf install finished (outbound gateway_client)"
  else
    log "peer.env is ready. Tunnel starts when the gateway file arrives, or re-run ./install.sh"
  fi
}

main
