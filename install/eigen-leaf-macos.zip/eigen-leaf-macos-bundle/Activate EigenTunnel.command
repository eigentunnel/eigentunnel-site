#!/usr/bin/env bash
# Double-click in Finder to activate an EigenTunnel leaf on this Mac.
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"

# Clear Gatekeeper quarantine on this pack (safe for our own download).
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
chmod +x "$ROOT/activate-and-register.sh" "$ROOT/leaf-pack/install.sh" "$ROOT/Activate EigenTunnel.command" 2>/dev/null || true
chmod +x "$ROOT"/bin/* 2>/dev/null || true

clear 2>/dev/null || true
echo "========================================"
echo "  EigenTunnel leaf — Mac activate"
echo "========================================"
echo
echo "Use the installer for the OS where this node will run."
echo "This pack is macOS only."
echo
echo "Private keys stay on this Mac. Do not email peer.env or identity.key."
echo
echo "If macOS blocked this file earlier: System Settings → Privacy & Security → Open Anyway."
echo


echo "Paste your activate link (or just the token), then press Return:"
read -r RAW
RAW="$(printf '%s' "$RAW" | tr -d '[:space:]')"
if [ -z "$RAW" ]; then
  echo "No token entered. Closing."
  read -r -p "Press Return to close…" _
  exit 1
fi
TOKEN="$RAW"
case "$RAW" in
  *token=*)
    TOKEN="${RAW#*token=}"
    TOKEN="${TOKEN%%&*}"
    ;;
esac
if [ -z "$TOKEN" ]; then
  echo "Could not read a token from what you pasted."
  read -r -p "Press Return to close…" _
  exit 1
fi

DEFAULT_NODE="leaf-$USER"
echo
echo "Node name for this Mac [${DEFAULT_NODE}]:"
read -r NODE_ID
NODE_ID="${NODE_ID:-$DEFAULT_NODE}"

echo
echo "Running activate for node: $NODE_ID"
echo

if ! "$ROOT/activate-and-register.sh" "$TOKEN" "$NODE_ID"; then
  echo
  echo "Activate failed. Keep this window open and send Patrick the error text."
  read -r -p "Press Return to close…" _
  exit 1
fi

echo
echo 'Success. You should have seen {"accepted":true}.'
echo "Tell Patrick this node is up: $NODE_ID"
read -r -p "Press Return to close…" _
