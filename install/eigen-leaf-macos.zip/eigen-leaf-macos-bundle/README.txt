EigenTunnel sandbox leaf (macOS)

Use the installer for the OS where this node will run.
This pack is macOS only (Apple Silicon + Intel).

Brain-dead path:
1) Unzip this folder (eigen-leaf-macos-bundle).
2) Double-click "Activate EigenTunnel.command".
   First time macOS may ask: right-click → Open → Open.
3) Paste your activate link (or token) when prompted.
4) Accept the suggested node name, or type leaf-yourname.
5) Expect {"accepted":true}.

Manual path (same result):
   chmod +x activate-and-register.sh leaf-pack/install.sh
   ./activate-and-register.sh 'PASTE_TOKEN_FROM_ACTIVATE_PAGE' leaf-yourname

Your private key is created on this Mac and never uploaded.
Do not email peer.env or identity.key.
Only share the activate link/token.
