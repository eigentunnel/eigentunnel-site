EigenTunnel sandbox leaf (macOS)

1) Unzip this folder.
2) Open Terminal in this folder.
3) Run:

   chmod +x activate-and-register.sh leaf-pack/install.sh
   ./activate-and-register.sh 'PASTE_TOKEN_FROM_ACTIVATE_PAGE' leaf-YOURNAME

4) Expect {"accepted":true}

Your private key is created on this Mac and never uploaded.
Do not email peer.env or identity.key.
Only share the activate link/token.
