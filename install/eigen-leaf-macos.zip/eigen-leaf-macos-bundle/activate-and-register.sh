#!/usr/bin/env bash
# Usage: ./activate-and-register.sh <activate-token> [node-id]
set -euo pipefail
TOKEN="${1:-}"
NODE_ID="${2:-leaf-$USER}"
if [ -z "$TOKEN" ]; then
  echo "usage: $0 <activate-token> [node-id]" >&2
  exit 1
fi
ROOT="$(cd "$(dirname "$0")" && pwd)"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64) SUFFIX=arm64 ;;
  x86_64) SUFFIX=x64 ;;
  *) echo "unsupported arch: $ARCH" >&2; exit 1 ;;
esac
BIN="$ROOT/bin"
export PATH="$BIN:$PATH"
ln -sfn "freeq-perf-identity-$SUFFIX" "$BIN/freeq-perf-identity"
ln -sfn "freeq-perf-identity-$SUFFIX" "$BIN/eigen-perf-identity"
ln -sfn "freeqd-$SUFFIX" "$BIN/freeqd"
export EIGEN_IDENTITY_BIN="$BIN/freeq-perf-identity"
PACK="$ROOT/leaf-pack"
API="${EIGENTUNNEL_RENDEZVOUS_URL:-https://66rkpxcki4.execute-api.us-east-2.amazonaws.com/dev}"
TENANT="${EIGENTUNNEL_TENANT_ID:-field-test}"
cd "$PACK"
./install.sh --name "$NODE_ID" --no-wait
PEER_ENV="$PACK/01-SEND-THIS-FILE/peer.env"
IDENTITY_KEY="$HOME/EigenTunnel/identity/identity.key"
if [ ! -f "$IDENTITY_KEY" ]; then
  echo "missing $IDENTITY_KEY after install" >&2
  exit 1
fi
# Rendezvous wants a short device key (32-byte x25519). peer.env EIGEN_PUBLIC_KEY_B64
# is a long PQ blob and the API rejects it as invalid.
PUB="$("$ROOT/bin/device-pubkey.py" "$IDENTITY_KEY")"
if [ -z "$PUB" ]; then
  echo "could not derive device public key from identity.key" >&2
  exit 1
fi

# vendored register script
REGISTER_PY="$ROOT/register-public-peer.py"
echo "Registering public peer for node=$NODE_ID (private key stays on this Mac)…"
EIGENTUNNEL_RENDEZVOUS_URL="$API" \
EIGENTUNNEL_ACTIVATE_TOKEN="$TOKEN" \
EIGENTUNNEL_TENANT_ID="$TENANT" \
EIGENTUNNEL_NODE_ID="$NODE_ID" \
EIGENTUNNEL_PEER_ID="$NODE_ID" \
EIGENTUNNEL_DEVICE_PUBLIC_KEY="$PUB" \
python3 "$REGISTER_PY"
echo "Done. Public peer registered. Do not email peer.env or identity.key."
