EigenTunnel — David EasyStart v2 (macOS)

IGNORE any earlier EigenTunnel install email from Patrick today.
USE ONLY this pack: EigenTunnel-David-EasyStart-v2.zip

Open START-HERE.txt and follow the five steps.

This pack is pre-set for leaf-davidmccormick.
Gateway connection info is already included.
Your private key is created on this Mac and never uploaded.
Send Patrick nothing.
