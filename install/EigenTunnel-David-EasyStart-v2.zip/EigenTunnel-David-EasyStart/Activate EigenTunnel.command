#!/usr/bin/env bash
# Double-click in Finder to activate EigenTunnel on this Mac (David EasyStart).
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"

xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
chmod +x "$ROOT/activate-and-register.sh" "$ROOT/leaf-pack/install.sh" "$ROOT/Activate EigenTunnel.command" 2>/dev/null || true
chmod +x "$ROOT"/bin/* 2>/dev/null || true

NODE_ID="leaf-davidmccormick"

clear 2>/dev/null || true
echo "========================================"
echo "  EigenTunnel — David EasyStart"
echo "========================================"
echo
echo "This Mac will be: $NODE_ID"
echo "Private keys stay on this Mac."
echo "Send Patrick nothing unless he asks."
echo
echo "If macOS blocked this file earlier:"
echo "  System Settings → Privacy & Security → Open Anyway."
echo
echo "Paste your activate token (or the full activate link), then press Return:"
read -r RAW
RAW="$(printf '%s' "$RAW" | tr -d '[:space:]')"
if [ -z "$RAW" ]; then
  echo "No token entered. Closing."
  read -r -p "Press Return to close…" _
  exit 1
fi
TOKEN="$RAW"
case "$RAW" in
  *token=*)
    TOKEN="${RAW#*token=}"
    TOKEN="${TOKEN%%&*}"
    ;;
esac
if [ -z "$TOKEN" ]; then
  echo "Could not read a token from what you pasted."
  read -r -p "Press Return to close…" _
  exit 1
fi

echo
echo "Activating $NODE_ID…"
echo

if ! "$ROOT/activate-and-register.sh" "$TOKEN" "$NODE_ID"; then
  echo
  echo "Activate failed. Keep this window open and tell Patrick the error text only if he asks."
  read -r -p "Press Return to close…" _
  exit 1
fi

echo
echo 'Success. You should have seen {"accepted":true}.'
echo "You are done. Send Patrick nothing unless he asks."
read -r -p "Press Return to close…" _
