EigenTunnel — Patrick EasyStart v2 (macOS)

Open START-HERE.txt and follow the five steps.

This pack is pre-set for leaf-patrickmccormick (overlay 10.66.0.2/24).
Gateway connection info is already included (3.130.82.45:51820).
Your private key is created on this Mac and never uploaded.

v2 fix: Activate EigenTunnel.command no longer trips macOS bash 3.2
"NODE_ID?: unbound variable" (Unicode ellipsis after $NODE_ID under set -u).
