#!/bin/bash
# Run by launchd as root. Starts eigentunneld, then gives its utun the overlay address, MTU and route.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
LOG="$ET_LOGS/leaf.log"; mkdir -p "$ET_LOGS" "$ET_STATE"; touch "$LOG"; chmod 644 "$LOG"
note() { printf '%s leaf-run: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >> "$ET_LOGS/leaf-run.log"; }
rm -f "$ET_STATE/utun"
if env | grep -q '^EIGENTUNNEL_E2E_RELAY_KEY'; then note "REFUSING START: static relay key variable present"; exit 1; fi
ulimit -c 0
echo "=== start $(date -u +%FT%TZ)" >> "$LOG"
"$ET_BIN/eigentunneld" --config "$ET_CONFIG" >> "$LOG" 2>&1 &
DPID=$!; trap 'kill -TERM $DPID 2>/dev/null; wait $DPID; exit 0' TERM INT
note "started eigentunneld pid=$DPID"
IFACE=""
for _ in $(seq 1 60); do
  kill -0 $DPID 2>/dev/null || break
  IFACE="$(awk '/=== start/{s=NR} {l[NR]=$0} END{for(i=s;i<=NR;i++) print l[i]}' "$LOG" | grep 'host TUN interface opened' | tail -1 | grep -o 'utun[0-9]*' | head -1)"
  [ -n "$IFACE" ] && break; sleep 0.5
done
if [ -n "$IFACE" ]; then
  /sbin/ifconfig "$IFACE" inet "${OVERLAY%/*}" "$GATEWAY_OVERLAY_IP" netmask 255.255.255.255 mtu "$MTU" up
  /sbin/route -q -n delete -net "$ROUTES" >/dev/null 2>&1 || true
  /sbin/route -q -n add -net "$ROUTES" -interface "$IFACE" >/dev/null 2>&1 && note "route $ROUTES -> $IFACE" || note "route add failed"
  echo "$IFACE" > "$ET_STATE/utun"; chmod 644 "$ET_STATE/utun"
else note "no utun seen; launchd will restart"; fi
wait $DPID; RC=$?; note "eigentunneld exited rc=$RC"; exit $RC
