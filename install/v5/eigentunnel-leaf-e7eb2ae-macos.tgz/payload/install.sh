#!/bin/bash
# EigenTunnel leaf installer v5 (built from eigentunnel-core e7eb2ae) - main part, run as root by et-install.sh.
#   install.sh --token <activation token> --user <mac user> [--new-key] [--dry-run]
# Fail closed: any failed step stops with a clear message. Safe to rerun: an existing v5 key is kept
# (so an approval already given stays valid) unless --new-key is passed.
set -uo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
TOKEN=""; TUSER=""; NEWKEY=0; DRY=0
while [ $# -gt 0 ]; do case "$1" in --token) TOKEN="$2"; shift 2;; --user) TUSER="$2"; shift 2;; --new-key) NEWKEY=1; shift;; --dry-run) DRY=1; shift;; *) echo "unknown argument $1"; exit 2;; esac; done
say() { printf '\n==> %s\n' "$*"; }
stop() { printf '\nSTOPPED: %s\n%s\nNothing insecure was left running. You can run the same command again later.\n' "$1" "${2:-}"; exit "${3:-1}"; }
[[ "$TOKEN" =~ ^[a-f0-9]{32}$ ]] || stop "the activation code in the command is missing or damaged." "Copy the whole one-line command from the email again."
[ "$DRY" = 1 ] || [ "$(id -u)" = 0 ] || stop "this step needs your Mac password (sudo)."
[ -n "$TUSER" ] || TUSER="${SUDO_USER:-$(id -un)}"
P="$PAYLOAD_DIR"
"$P/bin/eigentunneld" --version >/dev/null 2>&1 || stop "the EigenTunnel program will not run on this Mac ($(uname -m), macOS $(sw_vers -productVersion))."

if [ "$DRY" = 1 ]; then
  say "DRY RUN: key generation + the exact bytes that would be registered (nothing installed, nothing sent)"
  W=$(mktemp -d); "$P/bin/eigentunnel-perf-identity" --node-name "$NODE_NAME" --overlay-address "$OVERLAY" --output-dir "$W" >/dev/null || stop "key generation failed"
  PUBK=$(env_val "$W/peer.env" EIGENTUNNEL_PUBLIC_KEY_B64); KEMK=$(env_val "$W/peer.env" EIGENTUNNEL_KEM_KEY_B64)
  printf -- "-----BEGIN EIGENTUNNEL PUBLIC KEY-----\nnode_name=%s\npublic_key=%s\npublic_kem_key=%s\n-----END EIGENTUNNEL PUBLIC KEY-----\n" "$NODE_NAME" "$PUBK" "$KEMK" > "$W/register-body.txt"
  echo "would PUT $(wc -c < "$W/register-body.txt") bytes to $REGISTER_BASE/<token>/$NODE_NAME.pub ; body saved at $W/register-body.txt"
  echo "fingerprint: $(fingerprint "$PUBK" "$KEMK")"; echo "DRY_RUN_DIR=$W"; exit 0
fi

# ---- 1. keep an existing v5 key across reruns (idempotent), then remove every old install
KEEP=""
if [ "$NEWKEY" = 0 ] && [ -f "$ET_STATE/installer-v5" ] && [ -s "$ET_IDENTITY/identity.key" ] && [ -s "$ET_PUBLIC/peer.env" ]; then
  KEEP=$(mktemp -d /var/root/.et-keep.XXXXXX); chmod 700 "$KEEP"; cp -p "$ET_IDENTITY/identity.key" "$ET_PUBLIC/peer.env" "$KEEP/"
  say "1/6 Re-run: keeping this Mac's existing EigenTunnel key; removing old programs"
else
  say "1/6 Removing any old EigenTunnel / EasyStart install (services, programs, settings, old keys)"
fi
"$P/uninstall-old.sh" --user "$TUSER" || stop "could not remove the old install."
launchctl print "system/$ET_LABEL" >/dev/null 2>&1 && stop "an old EigenTunnel service is still loaded after cleanup."
pgrep -x eigentunneld >/dev/null && stop "an old EigenTunnel process is still running after cleanup."

# ---- 2. install programs
say "2/6 Installing EigenTunnel (build $BUILD)"
mkdir -p "$ET_BIN" "$ET_IDENTITY" "$ET_PUBLIC" "$(dirname "$ET_CONFIG")" "$ET_LOGS" "$ET_STATE" "$ET_ROOT/run"
install -m 755 "$P/bin/eigentunneld" "$P/bin/eigentunnel-perf-identity" "$ET_BIN/"
xattr -c "$ET_BIN/"* 2>/dev/null || true
install -m 755 "$P/common.sh" "$P/peers.conf" "$P/leaf-run.sh" "$P/uninstall-old.sh" "$P/self-test.sh" "$ET_ROOT/run/"
chown -R root:wheel "$ET_ROOT"; chmod 755 "$ET_ROOT" "$ET_LOGS" "$ET_STATE" "$ET_PUBLIC"; chmod 700 "$ET_IDENTITY"

# ---- 3. key (made HERE; the private key never leaves this Mac)
if [ -n "$KEEP" ]; then
  install -m 600 "$KEEP/identity.key" "$ET_IDENTITY/identity.key"; install -m 644 "$KEEP/peer.env" "$ET_PUBLIC/peer.env"; rm -rf "$KEEP"
  say "3/6 Using this Mac's existing key"
else
  say "3/6 Making a new key on this Mac (the private key never leaves it)"
  W=$(mktemp -d /var/root/.et-id.XXXXXX); chmod 700 "$W"
  "$ET_BIN/eigentunnel-perf-identity" --node-name "$NODE_NAME" --overlay-address "$OVERLAY" --output-dir "$W" --force >/dev/null || { rm -rf "$W"; stop "key generation failed."; }
  install -m 600 "$W/identity.key" "$ET_IDENTITY/identity.key"
  PUBK=$(env_val "$W/peer.env" EIGENTUNNEL_PUBLIC_KEY_B64); KEMK=$(env_val "$W/peer.env" EIGENTUNNEL_KEM_KEY_B64); rm -rf "$W"
  printf 'EIGENTUNNEL_NODE_NAME=%s\nEIGENTUNNEL_NODE_ADDRESS=%s\nEIGENTUNNEL_PUBLIC_KEY_B64=%s\nEIGENTUNNEL_KEM_KEY_B64=%s\n' "$NODE_NAME" "$OVERLAY" "$PUBK" "$KEMK" > "$ET_PUBLIC/peer.env"; chmod 644 "$ET_PUBLIC/peer.env"
fi
PUBK=$(env_val "$ET_PUBLIC/peer.env" EIGENTUNNEL_PUBLIC_KEY_B64); KEMK=$(env_val "$ET_PUBLIC/peer.env" EIGENTUNNEL_KEM_KEY_B64)
[ "$(printf %s "$PUBK" | openssl base64 -d -A | wc -c | tr -d ' ')" = 1952 ] && [ "$(printf %s "$KEMK" | openssl base64 -d -A | wc -c | tr -d ' ')" = 1216 ] || stop "the new public key has the wrong size."
touch "$ET_STATE/installer-v5"

# ---- 4. config + service
say "4/6 Starting EigenTunnel as a background service (starts again after a restart)"
cat > "$ET_CONFIG" <<CFG
# EigenTunnel leaf $NODE_NAME (build $BUILD). Outbound only: the gateway never dials this Mac.
[node]
name = "$NODE_NAME"
listen = "0.0.0.0:${LISTEN_PORT}"
address = "$OVERLAY"
key_path = "$ET_IDENTITY/identity.key"
algorithm = "ml-kem-768"
sign = "ml-dsa-65"
api_enabled = true
api_addr = "127.0.0.1:${API_PORT}"

[[peer]]
name = "aws-gateway"
mode = "gateway_client"
endpoint = "$GW_ENDPOINT"
public_key = "$GW_PUBLIC_KEY"
kem_key = "$GW_KEM_KEY"
allowed_ips = ["${ROUTES}", "${GATEWAY_OVERLAY_IP}/32"]
key_rotation_secs = 3600

# Always-on test leaf. Traffic to it is sealed end to end; the gateway only forwards envelopes.
[[peer]]
name = "$PARTNER_NAME"
mode = "relay_leaf"
public_key = "$PARTNER_PUBLIC_KEY"
kem_key = "$PARTNER_KEM_KEY"
allowed_ips = ["${PARTNER_IP}/32"]
CFG
chmod 644 "$ET_CONFIG"
cat > "$ET_PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$ET_LABEL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$ET_ROOT/run/leaf-run.sh</string></array>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/><key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$ET_LOGS/launchd.log</string><key>StandardErrorPath</key><string>$ET_LOGS/launchd.log</string>
</dict></plist>
PL
chown root:wheel "$ET_PLIST"; chmod 644 "$ET_PLIST"
: > "$ET_LOGS/leaf.log"
launchctl bootstrap system "$ET_PLIST" || stop "macOS would not start the EigenTunnel service."
for _ in $(seq 1 40); do [ -s "$ET_STATE/utun" ] && break; sleep 0.5; done
[ -s "$ET_STATE/utun" ] || stop "the tunnel interface did not come up." "Log: $ET_LOGS/leaf-run.log"

# ---- 5. register the PUBLIC key (bound to this activation code) and show the fingerprint
say "5/6 Registering this Mac's PUBLIC key with EigenTunnel (public key only)"
BODY=$(mktemp /tmp/et-pub.XXXXXX)
printf -- "-----BEGIN EIGENTUNNEL PUBLIC KEY-----\nnode_name=%s\npublic_key=%s\npublic_kem_key=%s\n-----END EIGENTUNNEL PUBLIC KEY-----\n" "$NODE_NAME" "$PUBK" "$KEMK" > "$BODY"
# guard: exactly 5 lines, only these fields, never the private key bytes
[ "$(wc -l < "$BODY" | tr -d ' ')" = 5 ] && ! grep -qiE 'PRIVATE|identity\.key|EIGENTUNNEL_IDENTITY' "$BODY" || { rm -f "$BODY"; stop "refusing to send: the registration file is not public-only."; }
PRIVB64=$(openssl base64 -A -in "$ET_IDENTITY/identity.key"); PRIVHEX=$(xxd -p "$ET_IDENTITY/identity.key" | tr -d '\n')
if grep -qF "$PRIVB64" "$BODY" || grep -qiF "$PRIVHEX" "$BODY"; then rm -f "$BODY"; stop "refusing to send: private key material detected."; fi
unset PRIVB64 PRIVHEX
CODE=$(/usr/bin/curl -sS -m 30 --proto '=https' --tlsv1.2 -o /dev/null -w '%{http_code}' -X PUT -H 'Content-Type: text/plain' --data-binary @"$BODY" "$REGISTER_BASE/$TOKEN/$NODE_NAME.pub") || CODE=000
rm -f "$BODY"
[ "$CODE" = 200 ] || stop "registration did not go through (HTTP $CODE)." "Check the internet connection and run the same command again. If it keeps failing, reply to the email with this line."
FP=$(fingerprint "$PUBK" "$KEMK")
cat <<MSG

   Registered. Your key FINGERPRINT (Patrick will phone you and ask you to read it):

         $FP

   Nothing to copy or send. Keep this window open.
MSG

# ---- 6. wait for Patrick's signed approval, then self-test
say "6/6 Waiting for approval (Patrick checks the fingerprint with you, then approves). Up to 60 minutes."
T0=$(date +%s); OK=0
while [ $(( $(date +%s) - T0 )) -lt 3600 ]; do
  if grep -q '"outbound peer session established"' "$ET_LOGS/leaf.log" 2>/dev/null || grep -q 'outbound peer session established' "$ET_LOGS/leaf.log"; then OK=1; break; fi
  sleep 15; printf '.'
done
echo
[ "$OK" = 1 ] || stop "not approved yet (the gateway still refuses this key, as it should until approval)." "EigenTunnel stays installed and keeps trying by itself. When Patrick says it is approved, run the same command again." 3
echo "Approved: the gateway accepted this Mac."
"$ET_ROOT/run/self-test.sh"
