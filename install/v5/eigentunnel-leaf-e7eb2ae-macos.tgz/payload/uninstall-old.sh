#!/bin/bash
# EigenTunnel EasyStart v4: remove every older EigenTunnel / FreeQ leaf install (v1, v2, v3, dev installs).
#
#   uninstall-old.sh --dry-run            list what would be stopped/removed (safe, no admin needed)
#   sudo uninstall-old.sh --user NAME     really remove (run as root; Start EigenTunnel does this for you)
#
# Scope "all" (default) = old installs + any previous v4 install. Scope "v4" = only this package's
# install root and LaunchDaemon (used for side-by-side testing). Nothing is kept: old keys are deleted.
set -uo pipefail
DRY=0; TARGET_USER="${SUDO_USER:-$(id -un)}"; SCOPE="${ET_UNINSTALL_SCOPE:-all}"
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY=1; shift ;;
    --user) TARGET_USER="$2"; shift 2 ;;
    --scope) SCOPE="$2"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
TARGET_HOME="$(dscl . -read "/Users/$TARGET_USER" NFSHomeDirectory 2>/dev/null | awk '{print $2}')"
[ -n "$TARGET_HOME" ] || TARGET_HOME="$(eval echo "~$TARGET_USER")"
if [ "$DRY" -eq 0 ] && [ "$(id -u)" -ne 0 ]; then
  echo "Real uninstall needs admin rights (run through Start EigenTunnel, or use --dry-run)." >&2; exit 1
fi
FOUND=0
act() { # act "description" command...
  FOUND=$((FOUND+1))
  if [ "$DRY" -eq 1 ]; then echo "  would: $1"; else echo "  doing: $1"; shift; "$@" 2>/dev/null || true; fi
}
echo "EigenTunnel old-install cleanup (scope=$SCOPE, user=$TARGET_USER, home=$TARGET_HOME, dry_run=$DRY)"

# 1. LaunchDaemons / LaunchAgents (stop first so nothing restarts the daemon)
plists=()
if [ "$SCOPE" = "v4" ]; then
  [ -e "$ET_PLIST" ] && plists+=("$ET_PLIST")
else
  for p in /Library/LaunchDaemons/com.eigentunnel.*.plist /Library/LaunchDaemons/io.eigentunnel.*.plist \
           /Library/LaunchDaemons/com.freeq.freeqd*.plist /Library/LaunchDaemons/io.freeq.*.plist \
           "$TARGET_HOME"/Library/LaunchAgents/com.eigentunnel.*.plist "$TARGET_HOME"/Library/LaunchAgents/io.eigentunnel.*.plist \
           "$TARGET_HOME"/Library/LaunchAgents/com.freeq.freeqd*.plist "$TARGET_HOME"/Library/LaunchAgents/io.freeq.*.plist; do
    [ -e "$p" ] && plists+=("$p")
  done
fi
for p in "${plists[@]+"${plists[@]}"}"; do
  label="$(basename "$p" .plist)"
  case "$p" in
    /Library/LaunchDaemons/*) act "stop + remove LaunchDaemon $p" sh -c "launchctl bootout system/$label; rm -f '$p'" ;;
    *) uid="$(id -u "$TARGET_USER")"; act "stop + remove LaunchAgent $p" sh -c "launchctl bootout gui/$uid/$label; rm -f '$p'" ;;
  esac
done

# 2. Running daemons (eigentunneld, freeqd) - also any started by hand / nohup / sudo
if [ "$SCOPE" = "v4" ]; then
  pids="$(pgrep -f "$ET_BIN/eigentunneld" || true)"
else
  pids="$( (pgrep -x eigentunneld; pgrep -x freeqd; pgrep -f '/bin/eigentunneld'; pgrep -f '/bin/freeqd') 2>/dev/null | sort -u | tr '\n' ' ')"
fi
for pid in $pids; do
  act "stop process $pid ($(ps -o command= -p "$pid" 2>/dev/null | cut -c1-120))" kill "$pid"
done
if [ "$DRY" -eq 0 ] && [ -n "$pids" ]; then sleep 2; for pid in $pids; do kill -9 "$pid" 2>/dev/null || true; done; fi

# 3. Files and folders
paths=()
if [ "$SCOPE" = "v4" ]; then
  paths+=("$ET_ROOT")
else
  paths+=(
    "$ET_ROOT"                                  # previous v4 install (fresh keys every time)
    "$TARGET_HOME/EigenTunnel"                  # v1-v3 EasyStart home (identity, config, logs, bin)
    "$TARGET_HOME/.eigentunnel"                 # scripted/dev installs (dist, perf, identity)
    "$TARGET_HOME/.freeq"                       # pre-rename installs
    "$TARGET_HOME/Library/Logs/EigenTunnel"     # v4 self-test reports
    /etc/eigentunnel /etc/freeq /usr/local/etc/eigentunnel /opt/homebrew/etc/eigentunnel
    /Library/Logs/EigenTunnel /var/log/eigentunnel /var/log/eigentunneld.log
  )
  # Old EasyStart packs (v1-v3) in Downloads / Desktop. Never touches a -v4 folder.
  for d in "$TARGET_HOME/Downloads" "$TARGET_HOME/Desktop"; do
    for p in "$d"/EigenTunnel-*EasyStart* "$d"/freeq-*leaf* "$d"/eigen-leaf-macos*; do
      [ -e "$p" ] || continue
      case "$p" in *-v4*|*v4.zip) continue ;; esac
      paths+=("$p")
    done
  done
  # Old leaf binaries on PATH (only files that really are EigenTunnel/FreeQ binaries)
  for b in eigentunneld eigentunnel eigentunnel-perf-identity eigentunnel-gateway et eigen freeqd freeq freeq-perf-identity eigen-perf-identity; do
    for dir in /usr/local/bin /opt/homebrew/bin "$TARGET_HOME/.local/bin" "$TARGET_HOME/bin"; do
      f="$dir/$b"; [ -e "$f" ] || [ -L "$f" ] || continue
      tgt="$(readlink "$f" 2>/dev/null || true)"
      if printf '%s' "$tgt" | grep -qiE 'eigentunnel|freeq' || grep -qaiE 'eigentunnel|freeq' "$f" 2>/dev/null; then paths+=("$f"); fi
    done
  done
  # ~/FreeQ and ~/freeq-core only when they are old leaf installs / old leaf source clones
  if [ -d "$TARGET_HOME/FreeQ" ] && { [ -d "$TARGET_HOME/FreeQ/identity" ] || [ -d "$TARGET_HOME/FreeQ/01-SEND-THIS-FILE" ] || [ -f "$TARGET_HOME/FreeQ/eigentunnel-setup.conf" ]; }; then
    paths+=("$TARGET_HOME/FreeQ")
  fi
  if [ -f "$TARGET_HOME/freeq-core/Cargo.toml" ] && grep -qiE 'freeq|eigentunnel' "$TARGET_HOME/freeq-core/Cargo.toml"; then
    paths+=("$TARGET_HOME/freeq-core")
  fi
fi
for p in "${paths[@]}"; do
  [ -e "$p" ] || [ -L "$p" ] || continue
  act "delete $p" rm -rf "$p"
done

# 4. Homebrew formula (old dev installs)
if [ "$SCOPE" != "v4" ]; then
  for brew in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [ -x "$brew" ] || continue
    if sudo -u "$TARGET_USER" "$brew" list --formula eigentunnel >/dev/null 2>&1; then
      act "brew uninstall eigentunnel" sudo -u "$TARGET_USER" "$brew" uninstall --force eigentunnel
    fi
  done
fi

if [ "$FOUND" -eq 0 ]; then echo "  nothing old found - already clean"; fi
[ "$DRY" -eq 1 ] && echo "Dry run only: nothing was changed." || echo "Old install removed. Old keys are gone; a new key is made next."
exit 0
