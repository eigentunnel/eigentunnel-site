#!/bin/bash
# EigenTunnel self-test (v5): this Mac -> gateway 3.130.82.45 -> always-on test leaf leaf-eigen (10.66.0.10).
# PASS only with proof of an end-to-end relay key AND replies. Prints one plain PASS or FAIL line with a clue.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
LOG="$ET_LOGS/leaf.log"; OUT="$ET_LOGS/self-test-latest.txt"
since() { awk '/=== start/{s=NR} {l[NR]=$0} END{for(i=s;i<=NR;i++) print l[i]}' "$LOG"; }
fail() { echo "SELF-TEST: FAIL - $1" | tee "$OUT"; exit 1; }
echo "Self-test: $(date '+%F %T %Z')"
launchctl print "system/$ET_LABEL" >/dev/null 2>&1 || fail "EigenTunnel service is not running (clue: run the install command again)."
since | grep -q 'outbound peer session established' || fail "the gateway has not accepted this Mac (clue: key not approved yet, or UDP 51820 to 3.130.82.45 is blocked)."
echo "  gateway session: OK"
PAIR=0
for _ in $(seq 1 18); do
  since | grep 'relay pair key installed' | grep -q "\"peer\":\"$PARTNER_NAME\"" && { PAIR=1; break; }
  ping -c 1 -t 2 "$PARTNER_IP" >/dev/null 2>&1; sleep 8
done
[ "$PAIR" = 1 ] || fail "no end-to-end key with the test leaf after 2.5 minutes (clue: approval not yet on the test leaf; support can see this)."
echo "  end-to-end relay key with $PARTNER_NAME: OK (the gateway never holds it)"
R=$(ping -c 5 -t 15 "$PARTNER_IP" 2>&1 | grep -o '[0-9]* packets received' | grep -o '^[0-9]*')
[ "${R:-0}" -ge 3 ] || fail "test leaf did not answer (${R:-0}/5) (clue: the path through the gateway drops packets)."
RTT=$(ping -c 5 -t 15 "$PARTNER_IP" 2>&1 | sed -n 's/.*= [0-9.]*\/\([0-9.]*\)\/.*/\1/p')
B=$(ping -D -s 1172 -c 3 -t 10 "$PARTNER_IP" 2>&1 | grep -o '[0-9]* packets received' | grep -o '^[0-9]*')
[ "${B:-0}" -ge 2 ] || fail "small packets work but full-size 1200-byte packets do not (${B:-0}/3) (clue: MTU on this network)."
echo "SELF-TEST: PASS - sealed round trips to $PARTNER_NAME through the gateway: $R/5 small, $B/3 full-size, avg ${RTT:-?} ms" | tee "$OUT"
