#!/bin/bash
# EigenTunnel leaf installer v5 (e7eb2ae) shared settings. Sourced by the other scripts.
PAYLOAD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$PAYLOAD_DIR/peers.conf"
NODE_NAME=leaf-david; OVERLAY=10.66.0.3/24; GATEWAY_OVERLAY_IP=10.66.0.254; ROUTES=10.66.0.0/24
LISTEN_PORT=51820; API_PORT=6789; MTU=1200; BUILD=e7eb2ae
PARTNER_OVERLAY_IP="$PARTNER_IP"
ET_ROOT="/Library/Application Support/EigenTunnel"; ET_LABEL=com.eigentunnel.leaf
ET_PLIST="/Library/LaunchDaemons/${ET_LABEL}.plist"; ET_BIN="$ET_ROOT/bin"; ET_IDENTITY="$ET_ROOT/identity"
ET_PUBLIC="$ET_ROOT/public"; ET_CONFIG="$ET_ROOT/config/leaf.toml"; ET_LOGS="$ET_ROOT/logs"; ET_STATE="$ET_ROOT/state"
MONITOR_URL="http://127.0.0.1:${API_PORT}/"
REGISTER_BASE="https://eigen-leaf-register-731770490294.s3.us-east-2.amazonaws.com/pending"
env_val() { sed -n "s/^$2=//p" "$1" | head -1 | sed "s/^'//; s/'\$//; s/^\"//; s/\"\$//"; }
monitor_token() { cat "$(dirname "$ET_CONFIG")/monitor.token" 2>/dev/null; }
api_get() { /usr/bin/curl -s -m 2 -H "Cookie: eigentunnel_monitor=$(monitor_token)" "http://127.0.0.1:${API_PORT}$1"; }
fingerprint() { # fingerprint PUBKEY_B64 KEMKEY_B64 -> XXXX-XXXX-XXXX-XXXX-XXXX-XXXX (same as the gateway's)
  { printf 'eigentunnel-leaf-fp-v1\000'; printf '%s' "$1" | /usr/bin/openssl base64 -d -A; printf '%s' "$2" | /usr/bin/openssl base64 -d -A; } \
    | /usr/bin/shasum -a 256 | cut -c1-24 | tr a-f A-F | sed 's/\(....\)/\1-/g; s/-$//'; }
